For 64bit Windows GUI wallet, run madbyte-qt-win64.exe
For 32bit Windows GUI wallet, run madbyte-qt-win32.exe

(version M004)
