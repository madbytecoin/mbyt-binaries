For GUI wallet on 64bit Ubuntu Linux, run madbyte-qt

Compiled library files are located in usr directory, copy them into
corresponding directories on your system if required.  Recommended 
to compile from source if you have problems or are running another
version of Linux.

(version M004)
